import UIKit

//My Collection

var collection: [String] = ["Perfumes", "Lip gloss"]
collection.append("Graphic Tees")
collection += ["Hair accessories", "Earrings", "Belts" , "Books"]

print("The collection contains\(collection.count) items.")
if collection.isEmpty {
print("The collection is empty.")
} else {
    print("The collection is full.")
}
var firstItem = collection [6]

for item in collection {
    print(item)

}

