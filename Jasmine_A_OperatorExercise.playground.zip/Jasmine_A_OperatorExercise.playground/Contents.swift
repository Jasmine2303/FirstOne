import UIKit

//Section 1
var a = 10
var b = 2
var c = 100
var d = 135
var e = 56
var f = 72
var g = 300
var h = 18
var i = 222
var j = 23
var k = 12
var l = 174

//Section 2
let cal1 = c/a
let cal2 = b*h
let cal3 = d-f
let cal4 = k+g
let cal5 = i*j*l
let cal6 = e*a-i
let cal7 = b+l+k
let cal8 = j-h+e
let cal9 = g/a
let cal10 = f+d+c
let cal11 = l+h+e+d
let cal12 = j*k


//Section 3
print(cal1)
print(cal2)
print(cal3)
print(cal4)
print(cal5)
print(cal6)
print(cal7)
print(cal8)
print(cal9)
print(cal10)
print(cal11)
print(cal12)




