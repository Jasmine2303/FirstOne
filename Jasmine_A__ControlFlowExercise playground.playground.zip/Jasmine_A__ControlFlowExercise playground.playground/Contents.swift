import UIKit

import UIKit

//My Collection

var collection: [String] = ["Perfumes", "Lip gloss"]
collection.append("Graphic Tees")
collection += ["Hair accessories", "Earrings", "Belts" , "Books"]

print("The collection contains\(collection.count) items.")
if collection.isEmpty {
print("The collection is empty.")
} else {
    print("The collection is full.")
}
var firstItem = collection [6]

for item in collection {
    print(item)

}

let companyArray = ["Perfumes", "Lip gloss", "Graphic Tees", "Hair accessories", "Earrings", "Belts" , "Books"]

let sortedArray = companyArray.sorted(by: {$0 < $1})
print (sortedArray)
