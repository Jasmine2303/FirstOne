import UIKit

var time = 180
for index in 1...180 {
        sleep(1)
    print("\(String(describing: index)) out of 180 ")

}
if time == 180{
    print ("time is up ")
   
}
